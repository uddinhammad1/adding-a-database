package org.example;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class Main  extends JFrame {
    private JTextField idField, titleField, genreField, yearField, ratingField, revenueField;
    private JTextField removeIdField, removeTitleField;
    private JTextArea displayArea;
    private MovieDAO movieDAO;

    public Main () {
        movieDAO = new MovieDAO();
        setTitle("Movie Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setSize(600, 400);

        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        idField = new JTextField();
        titleField = new JTextField();
        genreField = new JTextField();
        yearField = new JTextField();
        ratingField = new JTextField();
        revenueField = new JTextField();

        inputPanel.add(new JLabel("ID:"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Title:"));
        inputPanel.add(titleField);
        inputPanel.add(new JLabel("Genre:"));
        inputPanel.add(genreField);
        inputPanel.add(new JLabel("Year:"));
        inputPanel.add(yearField);
        inputPanel.add(new JLabel("Rating:"));
        inputPanel.add(ratingField);
        inputPanel.add(new JLabel("Revenue:"));
        inputPanel.add(revenueField);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 6));
        JButton addButton = new JButton("Add Movie");
        JButton viewButton = new JButton("View Movies");
        JButton batchUploadButton = new JButton("Batch Upload");
        JButton averageRatingButton = new JButton("Average Rating");
        JButton removeByIdButton = new JButton("Remove by ID");
        JButton removeByTitleButton = new JButton("Remove by Title");

        displayArea = new JTextArea(10, 50);
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);

        addButton.addActionListener(new AddMovieListener());
        viewButton.addActionListener(new ViewMoviesListener());
        batchUploadButton.addActionListener(new BatchUploadListener());
        averageRatingButton.addActionListener(new AverageRatingListener());
        removeByIdButton.addActionListener(new RemoveByIdListener());
        removeByTitleButton.addActionListener(new RemoveByTitleListener());

        buttonPanel.add(addButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(batchUploadButton);
        buttonPanel.add(averageRatingButton);
        buttonPanel.add(removeByIdButton);
        buttonPanel.add(removeByTitleButton);

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private class AddMovieListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String id = idField.getText();
                String title = titleField.getText();
                String genre = genreField.getText();
                int year = Integer.parseInt(yearField.getText());
                double rating = Double.parseDouble(ratingField.getText());
                String revenue = revenueField.getText();
                Movie movie = new Movie(id, title, genre, year, rating, revenue);
                movieDAO.addMovie(movie);
                displayArea.setText("Movie added successfully.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid numeric values for year and rating.");
            }
        }
    }

    private class ViewMoviesListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            displayArea.setText("");
            for (Movie movie : movieDAO.getAllMovies()) {
                displayArea.append(movie.toString() + "\n");
            }
        }
    }

    private class BatchUploadListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(null);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                movieDAO.batchUploadMoviesFromFile(selectedFile.getPath());
                displayArea.setText("Batch upload completed, duplicates ignored.");
            }
        }
    }

    private class AverageRatingListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            double avgRating = movieDAO.calculateAverageRating();
            displayArea.setText("Average Rating of Movies: " + avgRating);
        }
    }

    private class RemoveByIdListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String id = JOptionPane.showInputDialog("Enter Movie ID to Remove:");
            movieDAO.removeMovieById(id);
            displayArea.setText("Movie with ID " + id + " removed.");
        }
    }

    private class RemoveByTitleListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String title = JOptionPane.showInputDialog("Enter Movie Title to Remove:");
            movieDAO.removeMovieByTitle(title);
            displayArea.setText("Movie with Title '" + title + "' removed.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main gui = new Main ();
            gui.setVisible(true);
        });
    }
}
