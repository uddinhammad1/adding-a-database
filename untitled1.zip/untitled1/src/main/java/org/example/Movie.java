package org.example;

public class Movie {
    private String id;
    private String title;
    private String genre;
    private int year;
    private double rating;
    private String revenue;

    public Movie(String id, String title, String genre, int year, double rating, String revenue) {
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.year = year;
        this.rating = rating;
        this.revenue = revenue;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getGenre() { return genre; }
    public int getYear() { return year; }
    public double getRating() { return rating; }
    public String getRevenue() { return revenue; }

    @Override
    public String toString() {
        return String.format("ID: %s, Title: %s, Genre: %s, Year: %d, Rating: %.1f, Revenue: %s",
                id, title, genre, year, rating, revenue);
    }
}
